document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(7) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=nascar-class-a-fixed-2024-season-4-fixed.4f6715c5.js.map
