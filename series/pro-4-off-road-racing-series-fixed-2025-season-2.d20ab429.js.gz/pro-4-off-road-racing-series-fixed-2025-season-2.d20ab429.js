document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(7) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=pro-4-off-road-racing-series-fixed-2025-season-2.d20ab429.js.map
