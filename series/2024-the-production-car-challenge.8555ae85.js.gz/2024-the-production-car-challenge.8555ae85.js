document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(7) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=2024-the-production-car-challenge.8555ae85.js.map
