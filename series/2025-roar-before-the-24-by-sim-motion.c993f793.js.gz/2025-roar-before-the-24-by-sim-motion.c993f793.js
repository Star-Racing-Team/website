document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(7) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=2025-roar-before-the-24-by-sim-motion.c993f793.js.map
