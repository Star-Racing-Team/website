document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(3) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=emerson-estrella.723f09e7.js.map
