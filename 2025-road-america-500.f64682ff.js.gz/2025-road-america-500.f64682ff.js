document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(6) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=2025-road-america-500.f64682ff.js.map
