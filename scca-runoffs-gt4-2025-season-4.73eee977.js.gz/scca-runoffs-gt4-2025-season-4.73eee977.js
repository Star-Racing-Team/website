document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(7) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=scca-runoffs-gt4-2025-season-4.73eee977.js.map
