document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(5) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=imsa-endurance-series-2025-season-1.415997b3.js.map
