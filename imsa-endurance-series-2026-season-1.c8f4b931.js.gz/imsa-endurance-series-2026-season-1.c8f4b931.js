document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(6) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=imsa-endurance-series-2026-season-1.c8f4b931.js.map
