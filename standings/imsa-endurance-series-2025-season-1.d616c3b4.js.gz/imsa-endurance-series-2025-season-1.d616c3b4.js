document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(6) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=imsa-endurance-series-2025-season-1.d616c3b4.js.map
