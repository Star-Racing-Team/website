document.querySelectorAll(".sidebar li a").forEach(e=>{e.classList.remove("bg-active","text-active-text")}),document.querySelectorAll(".sidebar li:nth-child(6) a").forEach(e=>{e.classList.add("bg-active","text-active-text")});
//# sourceMappingURL=2024-bathurst-1000-us-presented-by-next-level-racing.431a7cf7.js.map
