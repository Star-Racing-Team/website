(0,globalThis.parcelRequire10c2.register)("iO6Mx",function(e,t){function i(){document.body.classList.add("light")}Object.defineProperty(e.exports,"setTheme",{get:()=>i,set:void 0,enumerable:!0,configurable:!0})});
//# sourceMappingURL=theme.485d509c.js.map
